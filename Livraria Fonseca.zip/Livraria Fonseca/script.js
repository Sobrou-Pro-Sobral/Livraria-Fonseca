// Suavizar Scroll ao clicar em "Compre Agora"
document.querySelector('.cta').addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector('#promocoes').scrollIntoView({ behavior: 'smooth' });
});

// Carrossel Promoções - Scroll Automático com Loop
let currentIndex = 0; // Índice inicial
const carousel = document.querySelector('.carousel');
const carouselItems = document.querySelectorAll('.carousel-item');
const totalItems = carouselItems.length;
const itemWidth = carouselItems[0].offsetWidth + 10; 

// Clonar os primeiros 5 itens para o final, criando um loop
for (let i = 0; i < 5; i++) {
    const clone = carouselItems[i].cloneNode(true);
    carousel.appendChild(clone);
}

function autoScrollCarousel() {
    currentIndex++;

    // Calcula a nova posição de rolagem
    const newScrollPosition = currentIndex * itemWidth;

    // Move o carrossel para a nova posição
    carousel.style.transform = `translateX(-${newScrollPosition}px)`;
    carousel.style.transition = 'transform 0.5s ease-in-out';

    // Quando chegamos ao final (contando os clones), fazemos o "reset" invisível
    if (currentIndex >= totalItems) {
        setTimeout(() => {
            carousel.style.transition = 'none'; // Desativa a transição temporariamente
            currentIndex = 0; // Reseta o índice para o início
            carousel.style.transform = 'translateX(0px)'; // Volta para a posição inicial
        }, 13); // Tempo de espera da transição para o último item
    }
}

// Função para reiniciar a transição após o reset
function restartTransition() {
    carousel.style.transition = 'transform 0.5s ease-in-out';
}

// Intervalo para rolar o carrossel automaticamente
setInterval(autoScrollCarousel, 1500); // Avança a cada 3 segundos
carousel.addEventListener('transitionend', restartTransition);

// Função que reinicia a transição após o reset
function restartTransition() {
    carousel.style.transition = 'transform 0.5s ease-in-out';
}

// Função para Scroll nas Seções (Mais Vendidos, Clássicos, Nacionais, Internacionais)
function scrollSection(sectionId, direction) {
    const section = document.getElementById(sectionId);
    const container = section.querySelector('.card-container');
    const cardWidth = container.querySelector('.card').offsetWidth + 20; // 20px de espaçamento entre cards
    const visibleCards = 5; // Quantidade de cards visíveis por vez
    const maxScroll = container.scrollWidth - container.clientWidth; // Tamanho máximo de scroll da seção

    let currentScroll = container.scrollLeft; // Posição atual de scroll
    let newScrollPosition = currentScroll + (direction * (cardWidth * visibleCards)); // Calcula o novo scroll

    // Limitar o scroll ao início ou ao final
    if (newScrollPosition < 0) {
        newScrollPosition = 0; // Não ultrapassar o início
    } else if (newScrollPosition > maxScroll) {
        newScrollPosition = maxScroll; // Não ultrapassar o final
    }

    // Realiza a rolagem suave
    container.scrollTo({
        left: newScrollPosition,
        behavior: 'smooth'
    });
}

// Adicionar evento nos botões de navegação para as seções (Ex: Mais Vendidos)
document.querySelectorAll('.prev, .next').forEach(button => {
    button.addEventListener('click', function() {
        const sectionId = this.closest('.section').id;
        const direction = this.classList.contains('prev') ? -1 : 1;
        scrollSection(sectionId, direction);
    });
});
// Mostrar Popup Balão ao clicar no card
document.querySelectorAll('.carousel-item, .card').forEach(item => {
    item.addEventListener('click', () => {
        const title = item.getAttribute('data-title');
        const author = item.getAttribute('data-author');
        const year = item.getAttribute('data-year');
        const price = item.getAttribute('data-price');
        const imgSrc = item.querySelector('img').src;

        document.getElementById('balloon-title').innerText = title;
        document.getElementById('balloon-author').innerText = `Autor: ${author}`;
        document.getElementById('balloon-year').innerText = `Ano: ${year}`;
        document.getElementById('balloon-price').innerText = `Preço: ${price}`;
        document.getElementById('balloon-cover').src = imgSrc;
        document.getElementById('balloon-popup').classList.remove('hidden');
    });
});

// Fechar Popup Balão
function closeBalloon() {
    document.getElementById('balloon-popup').classList.add('hidden');
}
